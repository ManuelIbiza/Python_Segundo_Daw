from django.apps import AppConfig


class App4BibliotecaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app4_biblioteca'
